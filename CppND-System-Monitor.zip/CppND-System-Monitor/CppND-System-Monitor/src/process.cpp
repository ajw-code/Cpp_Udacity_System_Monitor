#include <unistd.h>
#include <cctype>
#include <sstream>
#include <string>
#include <vector>
#include <iostream>

#include "process.h"
#include "linux_parser.h"
#include "format.h"

using std::string;
using std::to_string;
using std::vector;




// TODO: Return this process's ID
int Process::Pid() { return pid_; }

// TODO: Return this process's CPU utilization
float Process::CpuUtilization() { 
//   float pid_AJ=LinuxParser::ActiveJiffies(pid_);
//   float total_AJ=LinuxParser::ActiveJiffies();
//   float IJ = LinuxParser::IdleJiffies();
  
//   float util = pid_AJ/(total_AJ+IJ);
//   std::cout<<"Process Utilization: "<<util<<std::endl;
  
  float util, total_time, seconds;
  utime_=LinuxParser::getFieldFromProcess(pid_, utimeField_);
  stime_=LinuxParser::getFieldFromProcess(pid_, stimeField_);
  cutime_=LinuxParser::getFieldFromProcess(pid_, cutimeField_);
  cstime_=LinuxParser::getFieldFromProcess(pid_, cstimeField_);
  starttime_=LinuxParser::getFieldFromProcess(pid_, starttimeField_);
  
  total_time=stol(utime_)+stol(stime_)+stol(cutime_)+stol(cstime_);
  
  seconds=LinuxParser::UpTime(pid_) - (stol(starttime_)/sysconf(_SC_CLK_TCK));
  
  util = 100*((total_time/sysconf(_SC_CLK_TCK))/seconds);
  
  return util;
  
}

// TODO: Return the command that generated this process
string Process::Command() { return LinuxParser::Command(pid_); }

// TODO: Return this process's memory utilization
string Process::Ram() { return LinuxParser::Ram(pid_); }

// TODO: Return the user (name) that generated this process
string Process::User() { return LinuxParser::User(pid_); }

// TODO: Return the age of this process (in seconds)
long int Process::UpTime() { return LinuxParser::UpTime(pid_); }

// TODO: Overload the "less than" comparison operator for Process objects
// REMOVE: [[maybe_unused]] once you define the function
//sorting by process id
bool Process::operator<(Process const& ) const { 
  return true;
}