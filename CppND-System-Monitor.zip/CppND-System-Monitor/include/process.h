#ifndef PROCESS_H
#define PROCESS_H

#include <string>
/*
Basic class for Process representation
It contains relevant attributes as shown below
*/
class Process {
 public:
  int Pid();                               // TODO: See src/process.cpp
  std::string User();                      // TODO: See src/process.cpp
  std::string Command();                   // TODO: See src/process.cpp
  float CpuUtilization() const;                  // TODO: See src/process.cpp
  std::string Ram();                       // TODO: See src/process.cpp
  long int UpTime();                       // TODO: See src/process.cpp
  bool operator<(Process const& a) const;  // TODO: See src/process.cpp
     
  
  //Create Constructor based on Pid
  Process(int pid): pid_(pid){CpuUtiliziation_=CpuUtilization();}
  

  // TODO: Declare any necessary private members
 private:
  int pid_;
  float CpuUtiliziation_;
  
  int utimeField_ {14};
  int stimeField_ {15};
  int cutimeField_ {16};
  int cstimeField_ {17};
  int starttimeField_ {22};
  
  std::string utime_, stime_, cutime_, cstime_, starttime_;
};

#endif