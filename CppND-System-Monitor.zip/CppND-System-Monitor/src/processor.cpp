#include "processor.h"
#include "linux_parser.h"
#include <iostream>

// TODO: Return the aggregate CPU utilization
float Processor::Utilization() {   
  
  float util {0.0};
  float aj = LinuxParser::ActiveJiffies();
  float ij = LinuxParser::IdleJiffies();
  
  util = aj/(aj+ij);
  
  return util;

}