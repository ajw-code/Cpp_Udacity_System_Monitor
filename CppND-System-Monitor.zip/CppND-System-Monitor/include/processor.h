#ifndef PROCESSOR_H
#define PROCESSOR_H

class Processor {
 public:
  float Utilization();  // TODO: See src/processor.cpp
  Processor(){cpuUtilization=Utilization();}

  // TODO: Declare any necessary private members
 private:
  float cpuUtilization {0.0};
};

#endif